import express from "express";
import cors from "cors";
import helmet from "helmet"; // for http header security
import morgan from "morgan"; // request loggers
import path from "path";
import { fileURLToPath } from "url";

/* CONFIGURATION */
const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.json());

app.use(
  helmet({
    crossOriginOpenerPolicy: { policy: "same-origin-allow-popups" },
    crossOriginResourcePolicy: { policy: "cross-origin" },
  })
);

app.use(morgan("common"));
app.use(cors());
app.use(express.static(path.join(__dirname, "build")));

app.get("/*", (req, res) =>
  res.sendFile(path.join(__dirname, "build/index.html"))
);

var port = 8080;
const server = app.listen(port, function () {
  const host = server.address().address;
  const port = server.address().port;
  console.log("QuickRec Backend Server is Running at http://%s:%s", host, port);
});
